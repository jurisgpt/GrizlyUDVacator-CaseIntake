import streamlit as st
def render_external_form_tab():
    st.header("📨 Google Form")
    st.components.v1.iframe(
        src="https://docs.google.com/forms/d/e/1FAIpQLSc3RrptlqZctHOVmGGyoRPL38DfgmwCKYtkHZrIxlQGVReYiw/viewform?embedded=true",
        height=900
    )
