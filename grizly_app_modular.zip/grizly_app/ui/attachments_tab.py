import streamlit as st
def render_attachments_tab():
    st.header("📂 Evidence & Attachments")
    st.file_uploader("Upload evidence files", type=["pdf", "png", "jpg"], accept_multiple_files=True)
