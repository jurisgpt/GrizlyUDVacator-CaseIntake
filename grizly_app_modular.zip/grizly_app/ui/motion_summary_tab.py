import streamlit as st
def render_motion_tab():
    st.header("📑 Motion Summary")
    st.write("Generated motion text will appear here...")
