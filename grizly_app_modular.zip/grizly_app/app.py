import streamlit as st
from ui.intake_form_tab import render_intake_tab
from ui.motion_summary_tab import render_motion_tab
from ui.legal_reasoning_tab import render_reasoning_tab
from ui.decision_tree_tab import render_decision_tree_tab
from ui.attachments_tab import render_attachments_tab
from ui.external_form_tab import render_external_form_tab

st.set_page_config(page_title="Grizly UD Vacator", layout="wide")
st.title("⚖️ Grizly UD Vacator")
st.caption("Motion to Set Aside Default Judgment - CCP § 473.5")

tabs = st.tabs([
    "📋 Intake Form", 
    "📑 Motion Summary", 
    "🧠 Legal Reasoning", 
    "🌳 Decision Tree", 
    "📂 Attachments", 
    "📨 Google Form"
])

with tabs[0]: render_intake_tab()
with tabs[1]: render_motion_tab()
with tabs[2]: render_reasoning_tab()
with tabs[3]: render_decision_tree_tab()
with tabs[4]: render_attachments_tab()
with tabs[5]: render_external_form_tab()
